package com.example.model

enum class JobRole(
    val displayName: String,
    val suggestedSkills: List<String>,
    val roleExpectations: String
) {
    HR_EXECUTIVE(
        displayName = "HR Executive",
        suggestedSkills = listOf(
            "Talent Acquisition",
            "Employee Relations",
            "HRIS",
            "Onboarding",
            "Labor Compliance",
            "Payroll"
        ),
        roleExpectations = "Full-cycle recruitment, HRIS administration, onboarding, employee engagement, and labor policy compliance."
    ),
    PYTHON_DEVELOPER(
        displayName = "Python Developer",
        suggestedSkills = listOf(
            "Python",
            "FastAPI",
            "Django",
            "PostgreSQL",
            "REST APIs",
            "Docker",
            "Pytest"
        ),
        roleExpectations = "Production Python backend engineering, API design (FastAPI/Django), SQL databases, testing, and cloud deployment."
    ),
    SALES_MANAGER(
        displayName = "Sales Manager",
        suggestedSkills = listOf(
            "B2B Sales",
            "Pipeline Management",
            "Salesforce CRM",
            "Negotiation",
            "Quota Attainment",
            "Team Coaching"
        ),
        roleExpectations = "Revenue target ownership, B2B pipeline forecasting, CRM discipline, enterprise negotiation, and rep coaching."
    ),
    BUSINESS_ANALYST(
        displayName = "Business Analyst",
        suggestedSkills = listOf(
            "Requirements Gathering",
            "SQL",
            "Power BI",
            "Tableau",
            "BPMN",
            "Stakeholder Management"
        ),
        roleExpectations = "Business requirements elicitation, process modeling, data querying with SQL, dashboarding, and cross-functional alignment."
    )
}

enum class ShortlistStatus(val label: String) {
    SHORTLISTED("Shortlisted"),
    ON_HOLD("On Hold");

    companion object {
        fun fromApiValue(value: String): ShortlistStatus {
            return if (value.trim().equals("Shortlisted", ignoreCase = true)) {
                SHORTLISTED
            } else {
                ON_HOLD
            }
        }
    }
}

data class DashboardKpis(
    val totalResumes: Int = 48,
    val shortlisted: Int = 12,
    val pendingInterviews: Int = 5,
    val avgTimeToHireDays: Int = 14
)

data class CandidateScreeningInput(
    val candidateName: String,
    val jobRole: JobRole,
    val yearsOfExperience: Double,
    val keySkills: String
)

data class ScreeningResult(
    val id: String,
    val candidateName: String,
    val jobRole: JobRole,
    val yearsOfExperience: Double,
    val submittedSkills: List<String>,
    val matchScore: Int,
    val status: ShortlistStatus,
    val executiveSummary: String,
    val strengths: List<String>,
    val skillGaps: List<String>,
    val interviewQuestions: List<String>
)

sealed interface ScreeningUiState {
    data object Idle : ScreeningUiState
    data class Loading(
        val candidateName: String,
        val jobRole: JobRole
    ) : ScreeningUiState
    data class Success(val result: ScreeningResult) : ScreeningUiState
    data class Error(
        val message: String,
        val candidateName: String
    ) : ScreeningUiState
}
