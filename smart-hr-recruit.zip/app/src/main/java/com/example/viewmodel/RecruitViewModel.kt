package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CandidateScreeningRepository
import com.example.model.CandidateScreeningInput
import com.example.model.DashboardKpis
import com.example.model.JobRole
import com.example.model.ScreeningResult
import com.example.model.ScreeningUiState
import com.example.model.ShortlistStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

private const val TAG = "RecruitViewModel"

data class ScreeningFormState(
    val candidateName: String = "",
    val selectedRole: JobRole = JobRole.PYTHON_DEVELOPER,
    val yearsOfExperience: String = "",
    val keySkills: String = "",
    val nameError: String? = null,
    val experienceError: String? = null,
    val skillsError: String? = null
)

class RecruitViewModel(
    private val repository: CandidateScreeningRepository = CandidateScreeningRepository()
) : ViewModel() {

    private val _kpis = MutableStateFlow(DashboardKpis())
    val kpis: StateFlow<DashboardKpis> = _kpis.asStateFlow()

    private val _recentScreenings = MutableStateFlow<List<ScreeningResult>>(emptyList())
    val recentScreenings: StateFlow<List<ScreeningResult>> = _recentScreenings.asStateFlow()

    private val _formState = MutableStateFlow(ScreeningFormState())
    val formState: StateFlow<ScreeningFormState> = _formState.asStateFlow()

    private val _screeningUiState = MutableStateFlow<ScreeningUiState>(ScreeningUiState.Idle)
    val screeningUiState: StateFlow<ScreeningUiState> = _screeningUiState.asStateFlow()

    fun updateCandidateName(name: String) {
        _formState.update { it.copy(candidateName = name, nameError = null) }
    }

    fun updateJobRole(role: JobRole) {
        _formState.update { it.copy(selectedRole = role) }
    }

    fun updateYearsOfExperience(years: String) {
        val filtered = years.filter { it.isDigit() || it == '.' }
        _formState.update { it.copy(yearsOfExperience = filtered, experienceError = null) }
    }

    fun updateKeySkills(skills: String) {
        _formState.update { it.copy(keySkills = skills, skillsError = null) }
    }

    fun toggleSuggestedSkill(skill: String) {
        _formState.update { current ->
            val existing = current.keySkills
                .split(",")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .toMutableList()
            val existingLower = existing.map { it.lowercase() }
            if (skill.lowercase() in existingLower) {
                existing.removeAll { it.equals(skill, ignoreCase = true) }
            } else {
                existing.add(skill)
            }
            current.copy(
                keySkills = existing.joinToString(", "),
                skillsError = null
            )
        }
    }

    fun clearFormForNewCandidate() {
        _formState.update {
            ScreeningFormState(selectedRole = it.selectedRole)
        }
    }

    fun viewExistingResult(result: ScreeningResult) {
        _screeningUiState.value = ScreeningUiState.Success(result)
    }

    fun validateAndAnalyzeCandidate(): Boolean {
        val current = _formState.value
        val trimmedName = current.candidateName.trim()
        val parsedYears = current.yearsOfExperience.trim().toDoubleOrNull()
        val trimmedSkills = current.keySkills.trim()

        val nameError = if (trimmedName.isEmpty()) "Please enter the candidate's full name." else null
        val experienceError = when {
            current.yearsOfExperience.isBlank() -> "Please enter years of experience."
            parsedYears == null || parsedYears < 0.0 || parsedYears > 60.0 ->
                "Enter a valid experience between 0 and 60 years."
            else -> null
        }
        val skillsError = if (trimmedSkills.isEmpty()) "Please enter at least one key skill." else null

        if (nameError != null || experienceError != null || skillsError != null) {
            _formState.update {
                it.copy(
                    nameError = nameError,
                    experienceError = experienceError,
                    skillsError = skillsError
                )
            }
            return false
        }

        val input = CandidateScreeningInput(
            candidateName = trimmedName,
            jobRole = current.selectedRole,
            yearsOfExperience = parsedYears ?: 0.0,
            keySkills = trimmedSkills
        )
        runScreening(input)
        return true
    }

    fun retryScreening() {
        validateAndAnalyzeCandidate()
    }

    private fun runScreening(input: CandidateScreeningInput) {
        viewModelScope.launch {
            _screeningUiState.value = ScreeningUiState.Loading(
                candidateName = input.candidateName,
                jobRole = input.jobRole
            )
            try {
                val result = repository.screenCandidate(input)
                _screeningUiState.value = ScreeningUiState.Success(result)
                _recentScreenings.update { list -> listOf(result) + list }
                _kpis.update { current ->
                    current.copy(
                        totalResumes = current.totalResumes + 1,
                        shortlisted = if (result.status == ShortlistStatus.SHORTLISTED) {
                            current.shortlisted + 1
                        } else {
                            current.shortlisted
                        },
                        pendingInterviews = if (result.status == ShortlistStatus.SHORTLISTED) {
                            current.pendingInterviews + 1
                        } else {
                            current.pendingInterviews
                        }
                    )
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Candidate screening timed out", e)
                _screeningUiState.value = ScreeningUiState.Error(
                    message = "AI screening timed out after 60 seconds. Please check your connection and try again.",
                    candidateName = input.candidateName
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Candidate screening failed", e)
                _screeningUiState.value = ScreeningUiState.Error(
                    message = e.localizedMessage ?: "Unable to complete AI candidate screening. Please try again.",
                    candidateName = input.candidateName
                )
            }
        }
    }
}
