package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.WorkHistory
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.JobRole
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.CorporateCobalt
import com.example.ui.theme.CorporateNavy
import com.example.ui.theme.IceBlueBackground
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftBlueSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.ScreeningFormState

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CandidateScreeningScreen(
    formState: ScreeningFormState,
    onNameChange: (String) -> Unit,
    onRoleChange: (JobRole) -> Unit,
    onExperienceChange: (String) -> Unit,
    onSkillsChange: (String) -> Unit,
    onToggleSuggestedSkill: (String) -> Unit,
    onAnalyzeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var roleDropdownExpanded by remember { mutableStateOf(false) }

    val selectedSkillTokens = remember(formState.keySkills) {
        formState.keySkills
            .split(",")
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
            .toSet()
    }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = CorporateCobalt,
        unfocusedBorderColor = BorderSlate,
        focusedContainerColor = PureWhite,
        unfocusedContainerColor = PureWhite,
        focusedLabelColor = CorporateCobalt,
        cursorColor = CorporateCobalt
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(IceBlueBackground)
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 640.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = stringResource(R.string.screening_title),
                    style = MaterialTheme.typography.headlineMedium,
                    color = CorporateNavy
                )
                Text(
                    text = stringResource(R.string.screening_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = BorderStroke(1.dp, BorderSlate),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // 1. Candidate Name
                    OutlinedTextField(
                        value = formState.candidateName,
                        onValueChange = onNameChange,
                        label = { Text(stringResource(R.string.label_candidate_name)) },
                        placeholder = { Text(stringResource(R.string.placeholder_candidate_name)) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Rounded.Person,
                                contentDescription = null,
                                tint = CorporateCobalt
                            )
                        },
                        isError = formState.nameError != null,
                        supportingText = formState.nameError?.let { error ->
                            { Text(text = error) }
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Words,
                            imeAction = ImeAction.Next
                        ),
                        shape = RoundedCornerShape(14.dp),
                        colors = fieldColors,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("candidate_name_input")
                    )

                    // 2. Job Role Dropdown
                    ExposedDropdownMenuBox(
                        expanded = roleDropdownExpanded,
                        onExpandedChange = { roleDropdownExpanded = !roleDropdownExpanded },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = formState.selectedRole.displayName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(stringResource(R.string.label_job_role)) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.Badge,
                                    contentDescription = null,
                                    tint = CorporateCobalt
                                )
                            },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = roleDropdownExpanded)
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = fieldColors,
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .testTag("job_role_dropdown")
                        )

                        ExposedDropdownMenu(
                            expanded = roleDropdownExpanded,
                            onDismissRequest = { roleDropdownExpanded = false },
                            modifier = Modifier.background(PureWhite)
                        ) {
                            JobRole.entries.forEach { role ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = role.displayName,
                                            style = MaterialTheme.typography.bodyLarge,
                                            color = TextPrimary,
                                            fontWeight = if (role == formState.selectedRole) {
                                                FontWeight.SemiBold
                                            } else {
                                                FontWeight.Normal
                                            }
                                        )
                                    },
                                    onClick = {
                                        onRoleChange(role)
                                        roleDropdownExpanded = false
                                    },
                                    modifier = Modifier.testTag("role_option_${role.name.lowercase()}")
                                )
                            }
                        }
                    }

                    // 3. Years of Experience
                    OutlinedTextField(
                        value = formState.yearsOfExperience,
                        onValueChange = onExperienceChange,
                        label = { Text(stringResource(R.string.label_years_experience)) },
                        placeholder = { Text(stringResource(R.string.placeholder_years_experience)) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Rounded.WorkHistory,
                                contentDescription = null,
                                tint = CorporateCobalt
                            )
                        },
                        suffix = {
                            Text(
                                text = "yrs",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextMuted
                            )
                        },
                        isError = formState.experienceError != null,
                        supportingText = formState.experienceError?.let { error ->
                            { Text(text = error) }
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Decimal,
                            imeAction = ImeAction.Next
                        ),
                        shape = RoundedCornerShape(14.dp),
                        colors = fieldColors,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("years_experience_input")
                    )

                    // 4. Key Skills
                    OutlinedTextField(
                        value = formState.keySkills,
                        onValueChange = onSkillsChange,
                        label = { Text(stringResource(R.string.label_key_skills)) },
                        placeholder = { Text(stringResource(R.string.placeholder_key_skills)) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Rounded.Psychology,
                                contentDescription = null,
                                tint = CorporateCobalt
                            )
                        },
                        isError = formState.skillsError != null,
                        supportingText = formState.skillsError?.let { error ->
                            { Text(text = error) }
                        },
                        minLines = 3,
                        maxLines = 5,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Words,
                            imeAction = ImeAction.Done
                        ),
                        shape = RoundedCornerShape(14.dp),
                        colors = fieldColors,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("key_skills_input")
                    )

                    // Quick-tap Suggested Role Skills
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Quick-add ${formState.selectedRole.displayName} skills:",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            formState.selectedRole.suggestedSkills.forEach { skill ->
                                val isSelected = skill.lowercase() in selectedSkillTokens
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { onToggleSuggestedSkill(skill) },
                                    label = {
                                        Text(
                                            text = if (isSelected) skill else "+ $skill",
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = SoftBlueSurface,
                                        selectedLabelColor = CorporateCobalt,
                                        containerColor = IceBlueBackground,
                                        labelColor = TextSecondary
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = isSelected,
                                        borderColor = BorderSlate,
                                        selectedBorderColor = CorporateCobalt
                                    ),
                                    modifier = Modifier.testTag("skill_chip_${skill.lowercase().replace(" ", "_")}")
                                )
                            }
                        }
                    }
                }
            }

            // Submit CTA Button
            Button(
                onClick = onAnalyzeClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("analyze_candidate_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CorporateCobalt,
                    contentColor = PureWhite
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = stringResource(R.string.analyze_screen_cta),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
