package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PersonSearch
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.ScreeningResult
import com.example.model.ScreeningUiState
import com.example.model.ShortlistStatus
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.CorporateCobalt
import com.example.ui.theme.CorporateNavy
import com.example.ui.theme.IceBlueBackground
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftBlueSurface
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusAmberContainer
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusGreenContainer
import com.example.ui.theme.StatusRed
import com.example.ui.theme.StatusRedContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ScreeningResultsScreen(
    uiState: ScreeningUiState,
    onRetryClick: () -> Unit,
    onScreenAnotherClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(IceBlueBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 680.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = stringResource(R.string.results_title),
                    style = MaterialTheme.typography.headlineMedium,
                    color = CorporateNavy
                )
                Text(
                    text = "AI evaluation & role-tailored interview guide",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }

            when (uiState) {
                is ScreeningUiState.Idle -> {
                    IdleResultsCard(onScreenAnotherClick = onScreenAnotherClick)
                }

                is ScreeningUiState.Loading -> {
                    LoadingResultsCard(
                        candidateName = uiState.candidateName,
                        roleName = uiState.jobRole.displayName
                    )
                }

                is ScreeningUiState.Error -> {
                    ErrorResultsCard(
                        candidateName = uiState.candidateName,
                        errorMessage = uiState.message,
                        onRetryClick = onRetryClick,
                        onEditClick = onScreenAnotherClick
                    )
                }

                is ScreeningUiState.Success -> {
                    SuccessResultsContent(
                        result = uiState.result,
                        onScreenAnotherClick = onScreenAnotherClick
                    )
                }
            }

            // Mandatory Prototype Disclaimer Banner at the Bottom
            PrototypeDisclaimerBanner()
        }
    }
}

@Composable
private fun IdleResultsCard(onScreenAnotherClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, BorderSlate)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(SoftBlueSurface),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.PersonSearch,
                    contentDescription = null,
                    tint = CorporateCobalt,
                    modifier = Modifier.size(28.dp)
                )
            }
            Text(
                text = "No Screening Output Yet",
                style = MaterialTheme.typography.titleLarge,
                color = CorporateNavy,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Submit a candidate profile on the Screening screen to view their AI Match Score, Shortlist Status, Strengths, Skill Gaps, and 5 interview questions.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
            Button(
                onClick = onScreenAnotherClick,
                modifier = Modifier
                    .height(48.dp)
                    .testTag("go_to_screening_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CorporateCobalt,
                    contentColor = PureWhite
                )
            ) {
                Text(text = stringResource(R.string.screen_new_candidate_cta))
            }
        }
    }
}

@Composable
private fun LoadingResultsCard(
    candidateName: String,
    roleName: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("screening_loading_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, BorderSlate)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            CircularProgressIndicator(
                color = CorporateCobalt,
                trackColor = SoftBlueSurface,
                strokeWidth = 4.dp,
                modifier = Modifier.size(48.dp)
            )
            Text(
                text = "Analyzing $candidateName",
                style = MaterialTheme.typography.titleLarge,
                color = CorporateNavy,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Gemini AI is evaluating fit for $roleName, identifying skill gaps, and preparing 5 tailored interview questions...",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun ErrorResultsCard(
    candidateName: String,
    errorMessage: String,
    onRetryClick: () -> Unit,
    onEditClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("screening_error_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, StatusRed.copy(alpha = 0.35f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(StatusRedContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ErrorOutline,
                        contentDescription = null,
                        tint = StatusRed
                    )
                }
                Column {
                    Text(
                        text = "Screening Could Not Complete",
                        style = MaterialTheme.typography.titleMedium,
                        color = StatusRed
                    )
                    Text(
                        text = "Candidate: $candidateName",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            Text(
                text = errorMessage,
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onEditClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("edit_profile_button"),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, BorderSlate)
                ) {
                    Text("Edit Profile", color = CorporateNavy)
                }
                Button(
                    onClick = onRetryClick,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("retry_analysis_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CorporateCobalt,
                        contentColor = PureWhite
                    )
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Retry")
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SuccessResultsContent(
    result: ScreeningResult,
    onScreenAnotherClick: () -> Unit
) {
    val isShortlisted = result.status == ShortlistStatus.SHORTLISTED
    val scoreColor = when {
        result.matchScore >= 75 -> StatusGreen
        result.matchScore >= 55 -> CorporateCobalt
        else -> StatusAmber
    }

    // 1. Candidate Score & Status Hero Card
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("screening_success_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, BorderSlate),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = if (isShortlisted) StatusGreenContainer else StatusAmberContainer,
                        modifier = Modifier.testTag("shortlist_status_badge")
                    ) {
                        Text(
                            text = result.status.label,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (isShortlisted) StatusGreen else StatusAmber,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                        )
                    }

                    Text(
                        text = result.candidateName,
                        style = MaterialTheme.typography.headlineSmall,
                        color = CorporateNavy
                    )

                    Text(
                        text = "${result.jobRole.displayName} • ${result.yearsOfExperience} yrs experience",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                MatchScoreRing(
                    score = result.matchScore,
                    ringColor = scoreColor,
                    modifier = Modifier.testTag("match_score_gauge")
                )
            }

            HorizontalDivider(color = BorderSlate.copy(alpha = 0.7f))

            Row(
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = null,
                    tint = CorporateCobalt,
                    modifier = Modifier
                        .size(18.dp)
                        .padding(top = 2.dp)
                )
                Text(
                    text = result.executiveSummary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary
                )
            }

            if (result.submittedSkills.isNotEmpty()) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    result.submittedSkills.forEach { skill ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SoftBlueSurface
                        ) {
                            Text(
                                text = skill,
                                style = MaterialTheme.typography.labelSmall,
                                color = CorporateNavy,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    // 2. Candidate Strengths Card
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("strengths_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, BorderSlate)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.CheckCircle,
                    contentDescription = null,
                    tint = StatusGreen,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = stringResource(R.string.results_strengths),
                    style = MaterialTheme.typography.titleMedium,
                    color = CorporateNavy
                )
            }

            result.strengths.forEach { strength ->
                Row(
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .padding(top = 6.dp)
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(StatusGreen)
                    )
                    Text(
                        text = strength,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )
                }
            }
        }
    }

    // 3. Skill Gaps Card
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("skill_gaps_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, BorderSlate)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.WarningAmber,
                    contentDescription = null,
                    tint = StatusAmber,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = stringResource(R.string.results_skill_gaps),
                    style = MaterialTheme.typography.titleMedium,
                    color = CorporateNavy
                )
            }

            result.skillGaps.forEach { gap ->
                Row(
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .padding(top = 6.dp)
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(StatusAmber)
                    )
                    Text(
                        text = gap,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )
                }
            }
        }
    }

    // 4. 5 Tailored Interview Questions Card
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("interview_questions_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, BorderSlate)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Quiz,
                    contentDescription = null,
                    tint = CorporateCobalt,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = stringResource(R.string.results_interview_questions),
                    style = MaterialTheme.typography.titleMedium,
                    color = CorporateNavy
                )
            }

            result.interviewQuestions.forEachIndexed { index, question ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(SoftBlueSurface),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${index + 1}",
                            style = MaterialTheme.typography.labelMedium,
                            color = CorporateCobalt,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = question,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                }
                if (index < result.interviewQuestions.lastIndex) {
                    HorizontalDivider(color = BorderSlate.copy(alpha = 0.5f))
                }
            }
        }
    }

    // Screen Another Candidate CTA
    OutlinedButton(
        onClick = onScreenAnotherClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("screen_another_button"),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.2.dp, CorporateCobalt)
    ) {
        Icon(
            imageVector = Icons.Rounded.PersonSearch,
            contentDescription = null,
            tint = CorporateCobalt,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = stringResource(R.string.screen_new_candidate_cta),
            style = MaterialTheme.typography.labelLarge,
            color = CorporateCobalt
        )
    }
}

@Composable
private fun MatchScoreRing(
    score: Int,
    ringColor: Color,
    modifier: Modifier = Modifier
) {
    var targetProgress by remember(score) { mutableFloatStateOf(0f) }
    LaunchedEffect(score) {
        targetProgress = score / 100f
    }
    val animatedSweep by animateFloatAsState(
        targetValue = targetProgress * 360f,
        animationSpec = tween(durationMillis = 700),
        label = "MatchScoreSweep"
    )

    Box(
        modifier = modifier.size(88.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 9.dp.toPx()
            drawArc(
                color = Color(0xFFE5EDF9),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            drawArc(
                color = ringColor,
                startAngle = -90f,
                sweepAngle = animatedSweep,
                useCenter = false,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "$score%",
                style = MaterialTheme.typography.titleLarge,
                color = CorporateNavy,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Match",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
        }
    }
}

@Composable
private fun PrototypeDisclaimerBanner() {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("prototype_disclaimer_banner"),
        shape = RoundedCornerShape(12.dp),
        color = SoftBlueSurface.copy(alpha = 0.7f),
        border = BorderStroke(1.dp, BorderSlate)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.Info,
                contentDescription = null,
                tint = CorporateCobalt,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = stringResource(R.string.prototype_disclaimer),
                style = MaterialTheme.typography.labelMedium,
                color = CorporateNavy,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
