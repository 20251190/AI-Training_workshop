package com.example.ui

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.PersonSearch
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.PersonSearch
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.ui.navigation.Routes
import com.example.ui.screens.CandidateScreeningScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ScreeningResultsScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.CorporateCobalt
import com.example.ui.theme.CorporateNavy
import com.example.ui.theme.IceBlueBackground
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftBlueSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.RecruitViewModel

private data class PortalTab(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val portalTabs = listOf(
    PortalTab(
        route = Routes.DASHBOARD,
        labelRes = R.string.nav_dashboard,
        selectedIcon = Icons.Rounded.Dashboard,
        unselectedIcon = Icons.Outlined.Dashboard,
        testTag = "nav_tab_dashboard"
    ),
    PortalTab(
        route = Routes.SCREENING,
        labelRes = R.string.nav_screening,
        selectedIcon = Icons.Rounded.PersonSearch,
        unselectedIcon = Icons.Outlined.PersonSearch,
        testTag = "nav_tab_screening"
    ),
    PortalTab(
        route = Routes.RESULTS,
        labelRes = R.string.nav_results,
        selectedIcon = Icons.Rounded.Assessment,
        unselectedIcon = Icons.Outlined.Assessment,
        testTag = "nav_tab_results"
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartHrApp(
    recruitViewModel: RecruitViewModel = viewModel()
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination
    val currentRoute = currentDestination?.route ?: Routes.WELCOME

    val kpis by recruitViewModel.kpis.collectAsStateWithLifecycle()
    val recentScreenings by recruitViewModel.recentScreenings.collectAsStateWithLifecycle()
    val formState by recruitViewModel.formState.collectAsStateWithLifecycle()
    val screeningUiState by recruitViewModel.screeningUiState.collectAsStateWithLifecycle()

    val isPortalRoute = currentRoute != Routes.WELCOME

    fun navigateToPortalTab(route: String) {
        navController.navigate(route) {
            popUpTo(Routes.DASHBOARD) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            containerColor = IceBlueBackground,
            topBar = {
                if (isPortalRoute) {
                    Column {
                        TopAppBar(
                            title = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(CorporateCobalt),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Badge,
                                            contentDescription = null,
                                            tint = PureWhite,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Column {
                                        Text(
                                            text = stringResource(R.string.app_name),
                                            style = MaterialTheme.typography.titleMedium,
                                            color = CorporateNavy,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = when (currentRoute) {
                                                Routes.DASHBOARD -> "Dashboard Overview"
                                                Routes.SCREENING -> "Candidate Screening"
                                                Routes.RESULTS -> "Screening Results"
                                                else -> ""
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            },
                            actions = {
                                IconButton(
                                    onClick = {
                                        navController.navigate(Routes.WELCOME) {
                                            popUpTo(navController.graph.findStartDestination().id) {
                                                inclusive = true
                                            }
                                            launchSingleTop = true
                                        }
                                    },
                                    modifier = Modifier.testTag("logout_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Rounded.Logout,
                                        contentDescription = stringResource(R.string.logout_label),
                                        tint = CorporateNavy
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = PureWhite,
                                titleContentColor = CorporateNavy
                            )
                        )
                        HorizontalDivider(color = BorderSlate)
                    }
                }
            },
            bottomBar = {
                if (isPortalRoute && !useNavigationRail) {
                    Column {
                        HorizontalDivider(color = BorderSlate)
                        NavigationBar(
                            containerColor = PureWhite,
                            tonalElevation = 0.dp
                        ) {
                            portalTabs.forEach { tab ->
                                val selected = currentDestination?.hierarchy?.any {
                                    it.route == tab.route
                                } == true
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateToPortalTab(tab.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = stringResource(tab.labelRes)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = stringResource(tab.labelRes),
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = CorporateCobalt,
                                        selectedTextColor = CorporateCobalt,
                                        indicatorColor = SoftBlueSurface,
                                        unselectedIconColor = TextMuted,
                                        unselectedTextColor = TextMuted
                                    ),
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isPortalRoute && useNavigationRail) {
                    NavigationRail(
                        containerColor = PureWhite,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        portalTabs.forEach { tab ->
                            val selected = currentDestination?.hierarchy?.any {
                                it.route == tab.route
                            } == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToPortalTab(tab.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = stringResource(tab.labelRes)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(tab.labelRes),
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = CorporateCobalt,
                                    selectedTextColor = CorporateCobalt,
                                    indicatorColor = SoftBlueSurface,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted
                                ),
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = Routes.WELCOME,
                    enterTransition = { fadeIn(animationSpec = tween(220)) },
                    exitTransition = { fadeOut(animationSpec = tween(180)) },
                    modifier = Modifier.weight(1f)
                ) {
                    composable(Routes.WELCOME) {
                        WelcomeScreen(
                            onLoginClick = {
                                navController.navigate(Routes.DASHBOARD) {
                                    popUpTo(Routes.WELCOME) { inclusive = true }
                                    launchSingleTop = true
                                }
                            }
                        )
                    }

                    composable(Routes.DASHBOARD) {
                        DashboardScreen(
                            kpis = kpis,
                            recentScreenings = recentScreenings,
                            onScreenNewCandidateClick = {
                                navigateToPortalTab(Routes.SCREENING)
                            },
                            onSelectRecentResult = { result ->
                                recruitViewModel.viewExistingResult(result)
                                navigateToPortalTab(Routes.RESULTS)
                            }
                        )
                    }

                    composable(Routes.SCREENING) {
                        CandidateScreeningScreen(
                            formState = formState,
                            onNameChange = recruitViewModel::updateCandidateName,
                            onRoleChange = recruitViewModel::updateJobRole,
                            onExperienceChange = recruitViewModel::updateYearsOfExperience,
                            onSkillsChange = recruitViewModel::updateKeySkills,
                            onToggleSuggestedSkill = recruitViewModel::toggleSuggestedSkill,
                            onAnalyzeClick = {
                                if (recruitViewModel.validateAndAnalyzeCandidate()) {
                                    navigateToPortalTab(Routes.RESULTS)
                                }
                            }
                        )
                    }

                    composable(Routes.RESULTS) {
                        ScreeningResultsScreen(
                            uiState = screeningUiState,
                            onRetryClick = recruitViewModel::retryScreening,
                            onScreenAnotherClick = {
                                recruitViewModel.clearFormForNewCandidate()
                                navigateToPortalTab(Routes.SCREENING)
                            }
                        )
                    }
                }
            }
        }
    }
}
