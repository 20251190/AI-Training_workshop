package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Corporate Blue & Crisp White Palette
val CorporateNavy = Color(0xFF0A2540)
val CorporateCobalt = Color(0xFF1356B8)
val CorporateCobaltDark = Color(0xFF0B3C8A)
val CorporateSky = Color(0xFF0284C7)

val IceBlueBackground = Color(0xFFF5F8FD)
val PureWhite = Color(0xFFFFFFFF)
val SoftBlueSurface = Color(0xFFEBF2FC)
val BorderSlate = Color(0xFFD5E1F2)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF64748B)

// Semantic Status Colors
val StatusGreen = Color(0xFF0F8A5F)
val StatusGreenContainer = Color(0xFFE6F6EF)
val StatusAmber = Color(0xFFB45309)
val StatusAmberContainer = Color(0xFFFEF3C7)
val StatusRed = Color(0xFFB91C1C)
val StatusRedContainer = Color(0xFFFEE2E2)

// Dark Theme Tokens (fallback)
val DarkBackground = Color(0xFF091526)
val DarkSurface = Color(0xFF10213A)
val DarkSurfaceVariant = Color(0xFF1A3152)
val LightBluePrimary = Color(0xFF8BB8FF)
