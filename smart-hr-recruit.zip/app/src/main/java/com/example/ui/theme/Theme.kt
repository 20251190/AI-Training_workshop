package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = CorporateCobalt,
    onPrimary = PureWhite,
    primaryContainer = SoftBlueSurface,
    onPrimaryContainer = CorporateNavy,
    secondary = CorporateSky,
    onSecondary = PureWhite,
    secondaryContainer = ColorTokens.SecondaryContainer,
    onSecondaryContainer = CorporateNavy,
    tertiary = CorporateCobaltDark,
    onTertiary = PureWhite,
    background = IceBlueBackground,
    onBackground = TextPrimary,
    surface = PureWhite,
    onSurface = TextPrimary,
    surfaceVariant = SoftBlueSurface,
    onSurfaceVariant = TextSecondary,
    outline = BorderSlate,
    outlineVariant = ColorTokens.OutlineSubtle,
    error = StatusRed,
    onError = PureWhite,
    errorContainer = StatusRedContainer,
    onErrorContainer = StatusRed
)

private val DarkColorScheme = darkColorScheme(
    primary = LightBluePrimary,
    onPrimary = CorporateNavy,
    primaryContainer = CorporateCobaltDark,
    onPrimaryContainer = PureWhite,
    secondary = CorporateSky,
    onSecondary = PureWhite,
    background = DarkBackground,
    onBackground = PureWhite,
    surface = DarkSurface,
    onSurface = PureWhite,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = ColorTokens.DarkTextSecondary,
    outline = ColorTokens.DarkOutline,
    error = ColorTokens.DarkError,
    onError = CorporateNavy
)

private object ColorTokens {
    val SecondaryContainer = androidx.compose.ui.graphics.Color(0xFFE0F2FE)
    val OutlineSubtle = androidx.compose.ui.graphics.Color(0xFFE6EEF9)
    val DarkTextSecondary = androidx.compose.ui.graphics.Color(0xFFBBD0EB)
    val DarkOutline = androidx.compose.ui.graphics.Color(0xFF2D4B73)
    val DarkError = androidx.compose.ui.graphics.Color(0xFFFCA5A5)
}

val SmartHrShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp)
)

@Composable
fun SmartHrRecruitTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = SmartHrTypography,
        shapes = SmartHrShapes,
        content = content
    )
}
