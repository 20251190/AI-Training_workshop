package com.example.ui.navigation

object Routes {
    const val WELCOME = "welcome"
    const val DASHBOARD = "dashboard"
    const val SCREENING = "screening"
    const val RESULTS = "results"
}
