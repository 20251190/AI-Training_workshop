package com.example.data

import com.example.model.CandidateScreeningInput
import com.example.model.ScreeningResult
import com.example.model.ShortlistStatus
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.util.UUID

class CandidateScreeningRepository {

    private val screeningSchema = Schema.obj(
        properties = mapOf(
            "matchScore" to Schema.integer(
                description = "Overall candidate fit score from 0 to 100 based on role expectations, years of experience, and listed skills"
            ),
            "shortlistStatus" to Schema.enumeration(
                values = listOf("Shortlisted", "On Hold"),
                description = "Recommended HR status: Shortlisted if matchScore >= 70, otherwise On Hold"
            ),
            "executiveSummary" to Schema.string(
                description = "Two concise corporate HR sentences summarizing candidate suitability for the role"
            ),
            "strengths" to Schema.array(
                items = Schema.string(),
                description = "3 to 4 concrete candidate strengths aligned to the target role"
            ),
            "skillGaps" to Schema.array(
                items = Schema.string(),
                description = "2 to 4 missing or underdeveloped skills / risk areas to verify for the role"
            ),
            "interviewQuestions" to Schema.array(
                items = Schema.string(),
                description = "Exactly 5 tailored, high-signal interview questions specific to the job role and this candidate's background"
            )
        )
    )

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = screeningSchema
                temperature = 0.3f
            }
        )
    }

    suspend fun screenCandidate(input: CandidateScreeningInput): ScreeningResult {
        val prompt = buildString {
            appendLine("You are a senior corporate HR recruitment specialist.")
            appendLine("Evaluate the candidate below objectively for the target role and return structured screening results.")
            appendLine()
            appendLine("Candidate Name: ${input.candidateName}")
            appendLine("Target Job Role: ${input.jobRole.displayName}")
            appendLine("Role Benchmark: ${input.jobRole.roleExpectations}")
            appendLine("Years of Experience: ${input.yearsOfExperience}")
            appendLine("Candidate Key Skills: ${input.keySkills}")
            appendLine()
            appendLine("Evaluation Rules:")
            appendLine("1. matchScore must be an integer between 0 and 100.")
            appendLine("2. shortlistStatus must be 'Shortlisted' if matchScore >= 70, or 'On Hold' if matchScore < 70.")
            appendLine("3. Provide 3 to 4 specific strengths grounded in the candidate's skills and experience.")
            appendLine("4. Provide 2 to 4 realistic skillGaps relative to the target role benchmark.")
            appendLine("5. Provide exactly 5 tailored interviewQuestions calibrated to the candidate's experience level and skill gaps.")
        }

        val response = withTimeout(60_000L) {
            model.generateContent(prompt)
        }

        val jsonText = response.text
        if (jsonText.isNullOrBlank()) {
            throw IllegalStateException("Gemini returned an empty screening response.")
        }

        val json = JSONObject(jsonText)
        val rawScore = json.getInt("matchScore").coerceIn(0, 100)
        val statusString = json.getString("shortlistStatus")
        val status = ShortlistStatus.fromApiValue(statusString)
        val executiveSummary = json.getString("executiveSummary").trim()

        val strengthsArray = json.getJSONArray("strengths")
        val strengths = (0 until strengthsArray.length())
            .map { strengthsArray.getString(it).trim() }
            .filter { it.isNotEmpty() }

        val skillGapsArray = json.getJSONArray("skillGaps")
        val skillGaps = (0 until skillGapsArray.length())
            .map { skillGapsArray.getString(it).trim() }
            .filter { it.isNotEmpty() }

        val questionsArray = json.getJSONArray("interviewQuestions")
        val questions = (0 until questionsArray.length())
            .map { questionsArray.getString(it).trim() }
            .filter { it.isNotEmpty() }
            .take(5)

        val parsedSkills = input.keySkills
            .split(",", ";", "\n")
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        return ScreeningResult(
            id = UUID.randomUUID().toString(),
            candidateName = input.candidateName.trim(),
            jobRole = input.jobRole,
            yearsOfExperience = input.yearsOfExperience,
            submittedSkills = parsedSkills,
            matchScore = rawScore,
            status = status,
            executiveSummary = executiveSummary,
            strengths = strengths,
            skillGaps = skillGaps,
            interviewQuestions = questions
        )
    }
}
